import surviveImg from "../Assets/Images/Text.png"
import bannerImg from "../Assets/Images/img_header.png"
import socialIcon from "../Assets/Images/Social logos.png"
import arrow from "../Assets/Images/Group 12.png"
import card01 from "../Assets/Images/Mask Group 1.png"
import card02 from "../Assets/Images/img_fire.png"
import card03 from "../Assets/Images/meal.png"
import btn_more from "../Assets/Images/btn_more.png"
import img_shoes from "../Assets/Images/img_shoes.png"
import yourResult from "../Assets/Images/your results.png"
import youHave from "../Assets/Images/You have78% chance for survival.png"
import thirteen from "../Assets/Images/13.png"
import completedChallenges from "../Assets/Images/completed challenges.png"
import rectangle from "../Assets/Images/Rectangle 15.png"
import person from "../Assets/Images/Mask Group 2.png"
import crossMark from "../Assets/Images/cross-mark.png"
import advice from "../Assets/Images/advice.png"
import adventure from "../Assets/Images/Mask Group 4.png"
import pagination from "../Assets/Images/pagination.png"
import btn_next_ACTIVE from "../Assets/Images/btn_next_ACTIVE.svg"
import btn_next_passive from "../Assets/Images/btn_next_passive.svg"
import Lorem_ipsum_text from "../Assets/Images/lorem_text.svg" 
import survival_mode from "../Assets/Images/survival mode.png"
import forest_house from "../Assets/Images/forest house.png"
import ico_youtube from "../Assets/Images/ico_youtube.png"
import ShelterMaking from "../Assets/Images/Shelter making.png"
import lorem_white from "../Assets/Images/lorem white.png"
import tea from "../Assets/Images/tea.png"
import pictures from "../Assets/Images/pictures.png"
import gallery from "../Assets/Images/gallery.png"
import lorem_black from "../Assets/Images/lorem text black.png"
import footerBackground from "../Assets/Images/footerBackground.png"
import challenges from "../Assets/Images/challenges.png"
import AdventureBlack from "../Assets/Images/Group 9.png"
import advices from "../Assets/Images/advices.png"
import footergallery from "../Assets/Images/footergallery.png"
import social  from "../Assets/Images/social.png"

const Images ={
    surviveImg,
    bannerImg,
    socialIcon,
    arrow,
    card01,
    card02,
    card03,
    btn_more,
    img_shoes,
    yourResult,
    youHave,
    thirteen,
    completedChallenges,
    rectangle,
    person,
    crossMark,
    advice,
    pagination,
    adventure,
    btn_next_ACTIVE,
    btn_next_passive,
    Lorem_ipsum_text,
    survival_mode,
    forest_house,
    ico_youtube,
    ShelterMaking,
    lorem_white,
    tea,
    pictures,
    gallery,
    lorem_black,
    footerBackground,
    challenges,
    AdventureBlack,
    advices,
    footergallery,
    social
}
export default Images;