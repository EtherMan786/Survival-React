import FooterCard from "./FooterCard";
export default FooterCard