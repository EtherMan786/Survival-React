const SurviveModecard = ({img1}) =>{
    return <>
    <div>
        <img src={img1} alt="img1" />
    </div>
    </>
}
export default SurviveModecard;