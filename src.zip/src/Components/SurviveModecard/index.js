import SurviveModecard from "./SurviveModecard";
export default SurviveModecard;