import SurviveCard from "./SurviveCard";
export default SurviveCard;
