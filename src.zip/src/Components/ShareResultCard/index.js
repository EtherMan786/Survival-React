import ShareResultCard from "./ShareResultCard";
export default ShareResultCard;