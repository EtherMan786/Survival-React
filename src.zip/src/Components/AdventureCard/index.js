import AdventureCard from "./AdventureCard";
export default AdventureCard;