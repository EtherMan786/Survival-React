import PopularChallengeCard from "./PopularChallengeCard";
export default PopularChallengeCard;