import Banner from "../../Components/Banner";

const BannerContainer = () => {
    return <>
    <Banner/>
    {/* <div className="mainContent"> 
         <div className="leftContent"></div>
         <div className="rightContent"></div>
    </div> */}
    </>
}
export default BannerContainer;