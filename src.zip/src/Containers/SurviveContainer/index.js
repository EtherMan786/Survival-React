import SurviveContainer from "./SurviveContainer";
export default SurviveContainer;