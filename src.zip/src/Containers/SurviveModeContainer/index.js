import SurviveModeContainer from "./SurviveModeContainer";
export default SurviveModeContainer;